import pymysql

try:
    connection = pymysql.connect(
        host='localhost',
        user='root',
        password='kartiki',
        database='heart_predictor',
        auth_plugin_map={
            'mysql_native_password': 'mysql_native_password'
        }
    )
    print("✅ Connected!")
except pymysql.MySQLError as err:
    print("❌ Error:", err)
