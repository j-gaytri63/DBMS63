from flask import Flask, render_template, request, redirect, session, url_for, flash, get_flashed_messages
import numpy as np
import pickle
import mysql.connector
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)
app.secret_key = 's3cr3t_K3y_f0r_S3ss10n!'  # Required for session management

# Load trained model
with open(r"C:\Users\Sarthak\Desktop\MCAFinalYearProjectMachineLearning\heart_disease_rf_model.pkl", "rb") as file:
    model = pickle.load(file)

# DB connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="heart_predictor"
)
cursor = db.cursor()

# Function to validate heart prediction inputs
def validate_input(input_data):
    errors = []
    if not (18 <= input_data["Age"] <= 100):
        errors.append("Age should be between 18 and 100.")
    if input_data["Sex"] not in [0, 1]:
        errors.append("Invalid value for Sex. Use 0 (Female) or 1 (Male).")
    if input_data["ChestPainType"] not in [0, 1, 2, 3]:
        errors.append("Invalid Chest Pain Type (must be 0, 1, 2, or 3).")
    if not (90 <= input_data["RestingBP"] <= 200):
        errors.append("RestingBP must be between 90 and 200 mmHg.")
    if not (100 <= input_data["Cholesterol"] <= 600):
        errors.append("Cholesterol must be between 100 and 600 mg/dL.")
    if input_data["FastingBS"] not in [0, 1]:
        errors.append("Invalid value for FastingBS (should be 0 or 1).")
    if input_data["RestingECG"] not in [0, 1, 2]:
        errors.append("Invalid RestingECG value (must be 0, 1, or 2).")
    if not (60 <= input_data["MaxHR"] <= 220):
        errors.append("MaxHR must be between 60 and 220 bpm.")
    if input_data["ExerciseAngina"] not in [0, 1]:
        errors.append("Invalid ExerciseAngina value (should be 0 or 1).")
    if not (-2.0 <= input_data["Oldpeak"] <= 6.0):
        errors.append("Oldpeak should be between -2.0 and 6.0.")
    if input_data["ST_Slope"] not in [0, 1, 2]:
        errors.append("Invalid ST_Slope value (must be 0, 1, or 2).")
    return errors

@app.route('/')
def login_page():
    return render_template("login.html")

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        fullname = request.form['fullname']
        mobile = request.form['mobile']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirmPassword']

        if password != confirm_password:
            return render_template("register.html", error="Passwords do not match")

        try:
            cursor.execute("INSERT INTO users (fullname, mobile, email, password) VALUES (%s, %s, %s, %s)",
                           (fullname, mobile, email, password))
            db.commit()
            flash("Login successful!")
            return redirect(url_for('home'))

        except Exception as e:
            return render_template("register.html", error=str(e))

    return render_template("register.html")

@app.route('/login', methods=['POST'])
def login():
    email = request.form['email']
    password = request.form['password']

    cursor.execute("SELECT * FROM users WHERE email=%s AND password=%s", (email, password))
    user = cursor.fetchone()

    if user:
        session['user'] = user[1]  # fullname
        return render_template("login.html", success="Login successful! Redirecting to Heart Disease Prediction...")
    else:
        return render_template("login.html", error="Invalid credentials", request=None)


@app.route('/home')
def home():
    if 'user' not in session:
        return redirect(url_for('login_page'))
    
    return render_template("index.html", username=session['user'])  # Send name to template

@app.route("/predict", methods=["POST"])
def predict():
    if 'user' not in session:
        return redirect(url_for('login'))

    try:
        input_data = {
            "Age": int(request.form["Age"]),
            "Sex": int(request.form["Sex"]),
            "ChestPainType": int(request.form["ChestPainType"]),
            "RestingBP": int(request.form["RestingBP"]),
            "Cholesterol": int(request.form["Cholesterol"]),
            "FastingBS": int(request.form["FastingBS"]),
            "RestingECG": int(request.form["RestingECG"]),
            "MaxHR": int(request.form["MaxHR"]),
            "ExerciseAngina": int(request.form["ExerciseAngina"]),
            "Oldpeak": float(request.form["Oldpeak"]),
            "ST_Slope": int(request.form["ST_Slope"])
        }

        errors = validate_input(input_data)
        if errors:
            return render_template("index.html", errors=errors)

        features = np.array([list(input_data.values())]).reshape(1, -1)
        prediction = model.predict(features)
        result = "Heart Disease Detected" if prediction[0] == 1 else "No Heart Disease"

        return render_template("index.html", prediction=result)

    except Exception as e:
        return render_template("index.html", error=f"Error: {str(e)}")
    
@app.route('/receipt', methods=['POST'])
def receipt():
    if 'user' not in session:
        return redirect(url_for('login'))

    patient_name = request.form['patient_name']
    age = request.form['age']
    sex = request.form['sex']
    result = request.form['result']

    # Convert sex to gender
    gender = "Male" if sex == "1" else "Female"

    # General precautions
    precautions = [
        "Maintain a balanced diet with low sodium and fats.",
        "Exercise regularly as recommended by a doctor.",
        "Avoid tobacco, alcohol, and manage stress levels.",
        "Monitor blood pressure, sugar, and cholesterol regularly.",
        "Take prescribed medication on time.",
        "Regular heart checkups are advised."
    ]

    return render_template("receipt.html",
                           patient_name=patient_name,
                           gender=gender,
                           age=age,
                           result=result,
                           precautions=precautions)

if __name__ == "__main__":
    app.run(debug=True)
